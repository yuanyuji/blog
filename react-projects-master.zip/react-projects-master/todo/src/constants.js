export const FilterTypes = {
	ALL: '全部',
	COMPLETED: '已完成',
	UNCOMPLETED: '未完成'
}