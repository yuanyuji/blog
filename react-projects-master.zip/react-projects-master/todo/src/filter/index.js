import * as actions from './actions.js';
import reducer from './reducer.js';
import view from './view/filters.js';

export {
	actions,
	reducer,
	view
};