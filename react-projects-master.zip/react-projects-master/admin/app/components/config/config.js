const SERVER_IP = '127.0.0.1';
const SERVER_PORT = '8080';

export const SERVER_ADDRESS = 'http://' + SERVER_IP + ':' + SERVER_PORT;