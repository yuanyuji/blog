import React from 'react';

import GatherDetail from '../components/gather-detail';

const NewGather = () => (
	<GatherDetail />
)

export {
	NewGather
};