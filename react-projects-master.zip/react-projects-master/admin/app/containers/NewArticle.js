import React from 'react';

import ArticleDetail from '../components/article-detail';

const NewArticle = () => (
	<ArticleDetail />
)

export {
	NewArticle
};