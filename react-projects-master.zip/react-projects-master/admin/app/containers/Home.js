import React from 'react';

import SystemInfo from '../components/system-info';

export default () => (
	<SystemInfo />
)