export const FETCH_START = 'GOSSIP/START';
export const FETCH_SUCCEED = 'GOSSIP/SUCCEED';
export const FETCH_FAIL = 'GOSSIP/FAIL';