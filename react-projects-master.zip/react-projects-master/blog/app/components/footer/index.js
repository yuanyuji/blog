import {Link} from 'react-router';
import React, {Component} from 'react';

import './index.scss';

export default () => (
	<footer className="footer">
		<p><a href='http://112.74.36.170:8081/index.php'>旧主页</a></p>
		<p><span>Marco © 2016-2017 All rights reserved</span></p>
	</footer>
)
