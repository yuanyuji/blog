export const FETCH_START = 'NOTE/START';
export const FETCH_SUCCEED = 'NOTE/SUCCEED';
export const FETCH_FAIL = 'NOTE/FAIL';