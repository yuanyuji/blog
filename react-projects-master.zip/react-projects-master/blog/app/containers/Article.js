import React from 'react';

import Articles from '../components/articles';

const Article = () => (
	<Articles />
);


export {
    Article
}