const SERVERIP = '127.0.0.1';
const SERVERPORT = '3000';

export const SERVERADDRESS = 'http://' + SERVERIP + ':' + SERVERPORT;